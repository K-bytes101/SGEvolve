import init, { compute_score } from './a7a9e57e.js';
await init();

self.addEventListener('message', msg => {
	const input = msg.data[0];
	const output = msg.data[1];
	const ret = compute_score(input, output);
	self.postMessage([ret.score, ret.error, ret.fs, input, output]);
})
