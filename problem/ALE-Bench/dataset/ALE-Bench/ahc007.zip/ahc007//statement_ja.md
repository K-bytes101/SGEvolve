ストーリー
--------
巨大企業のAtCoder社は多数のオフィスを所有している。
超機密情報である出題予定の問題文を安全に共有するため、いくつかのオフィス間に量子暗号を用いた専用回線を敷くことにした。
専用回線で結ぶオフィスペアの候補はいくつかあり、全てのオフィスが専用回線によって連結となるようにしたい。
専用回線を敷く費用は回線の長さに比例するが、物理的な制約により直線で引けるとは限らないため、各候補について正確な費用の見積もりを業者に依頼している。
高橋社長はせっかちなため、一つの候補についての見積もりを受け取ったら、即座にその回線を敷くかどうかを決定する。
高橋社長のサポートをして、出来るだけ安い費用で目的を達成してほしい。


問題文
--------
頂点数が $N$、辺の数が $M$ の無向グラフが与えられる。
各頂点は二次元平面上にあり、$i$ 番目の頂点の座標は $(x_i, y_i)$ である。
$i$ 番目の辺は頂点 $u_i$ と $v_i$ を結び、その長さ $l_i$ は、端点の間のユークリッド距離を整数に四捨五入したものを $d_i=\mathrm{round}(\sqrt{(x_{u_i}-x_{v_i})^2+(y_{u_i}-y_{v_i})^2})$ とすると、
$d_i \leq l_i \leq 3 d_i$ を満たすことが事前に分かっている。

辺の長さ $l_i$ の正確な情報が $i=0$ 番目の辺から $i=M-1$ 番目の辺まで順番に一つずつ与えられる。
辺の長さの情報を一つ受け取ったら、次の辺の情報を受け取る前に、その辺を採用するかしないかを決定せよ。

最終的に採用した辺の集合を $S$ としたとき、全ての頂点対について、$S$ に含まれる辺のみを通って行き来出来なければならない。
採用した辺の総長が出来るだけ短くなるように意思決定して欲しい。

入出力
--------
全てのテストケースにおいて、$N=400$、$M=1995$ で固定である。
まずはじめに、$N$ 個の頂点の座標 $(x_0,y_0), \cdots, (x_{N-1},y_{N-1})$ と、$M$ 個の辺の端点 $(u_0,v_0), \cdots, (u_{M-1},v_{M-1})$ が以下の形式で標準入力から与えられる。
~~~
$x_0$ $y_0$
$\vdots$
$x_{N-1}$ $y_{N-1}$
$u_0$ $v_0$
$\vdots$
$u_{M-1}$ $v_{M-1}$
~~~
以下を満たすことが保証されている。

- $0\leq x_i,y_i\leq 800$
- $0\leq u_i<v_i\leq N-1$
- 同じ $(u_i,v_i)$ のペアは複数回現れることはない。
- グラフは連結である。

次に、以下の処理を $M$ 回繰り返す。

$i$ 回目 ($0\leq i\leq M-1$) の処理では、まず $i$ 番目の辺の長さ $l_i$ が $d_i$ 以上 $3d_i$ 以下の整数値から一様ランダムに生成され、標準入力に一行で与えられる。
$l_i$ の値を読み込んだら、$i$ 番目の辺を採用する場合には `1` を、採用しない場合は `0` を一行で標準出力に出力せよ。
<font color="red">**出力を行うまで、次の入力は与えられないので注意せよ。出力のあとは標準出力を flush しなければならない。**</font>そうしない場合、<span class='label label-warning' data-toggle='tooltip' data-placement='top' title="実行時間制限超過">TLE</span>となる可能性がある。

例
--------
<table class="table table-bordered">
<thead>
<tr>
<th align="left">$i$</th>
<th align="left">Input</th>
<th align="left">Output</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">事前情報</td>
<td align="left"><pre>
406 19
347 786
$\vdots$
21 191
</pre></td>
<td align="left"></td>
<tr>
<td align="left">$0$</td>
<td align="left"><pre>69</pre></td>
<td align="left"><pre>1</pre></td>
</tr>
<tr>
<td align="left">$1$</td>
<td align="left"><pre>89</pre></td>
<td align="left"><pre>0</pre></td>
</tr>
<tr>
<td align="center" colspan="3">$\vdots$</td>
</tr>
<tr>
<td align="left">$M-1$</td>
<td align="left"><pre>175</pre></td>
<td align="left"><pre>0</pre></td>
</tr>
</tbody>
</table>

得点
--------
採用した辺集合の総長を $A$、
各辺の真の長さ $l_i$ を事前に全て知っている状態での最適な辺の選び方 (<a href="https://ja.wikipedia.org/wiki/%E5%85%A8%E5%9F%9F%E6%9C%A8#%E6%9C%80%E5%B0%8F%E5%85%A8%E5%9F%9F%E6%9C%A8">最小全域木</a>) の総長を $B$ とすると、$\mathrm{round}(10^8\times B/A)$ の得点が得られる。
採用した辺集合がグラフを連結にしない場合は、<span class='label label-warning' data-toggle='tooltip' data-placement='top' title="不正解">WA</span> と判定される。
提出プログラムが異常終了した場合、 <span class='label label-warning' data-toggle='tooltip' data-placement='top' title="実行時エラー">RE</span> ではなく <span class='label label-warning' data-toggle='tooltip' data-placement='top' title="不正解">WA</span> と判定される場合があるので注意せよ。

テストケースは全部で 150 個あり、各テストケースの得点の合計が提出の得点となる。
1つ以上のテストケースで <span class='label label-success' data-toggle='tooltip' data-placement='top' title="正解">AC</span> 以外の判定がされた場合、提出の得点は0点となる。
コンテスト時間中に得た最高得点で最終順位が決定され、コンテスト終了後のシステムテストは行われない。
同じ得点を複数の参加者が得た場合、その得点を獲得した提出の早い方が上位となる。


入力生成方法
--------
$L$ 以上 $U$ 以下の整数値を一様ランダムに生成する関数を $\mathrm{rand}(L,U)$ で表す。

#### $(x_i,y_i)$ の生成
各 $i=0,\cdots,N-1$ に対して順番に、$x_i=\mathrm{rand}(0,800)$、$y_i=\mathrm{rand}(0,800)$ を生成する。
既に生成した頂点の座標$(x_j,y_j)$ ($j<i$)とのユークリッド距離が $5$ 以下の間、生成をやり直す。

#### $(u_i,v_i)$ の生成
頂点 $i$ と頂点 $j$ の間に長さ $\mathrm{round}(\sqrt{(x_i-x_j)^2+(y_i-y_j)^2})$ の辺を張った完全グラフを $G$ とする。
以下の処理を $5$ 回繰り返すことで、$M=5(N-1)$ 本の辺集合 $E$ を生成する。

> $G$ の最小全域木 $T$ を一つ求め、$T$ に含まれる辺を全て $G$ から削除し、$E$ に追加する。

最後に、$E$ に含まれる辺をランダムな順番に並び替えることで、$(u_0,v_0),\cdots,(u_{M-1},v_{M-1})$ を生成する。

#### $l_i$ の生成
端点の間のユークリッド距離を整数に四捨五入したものを $d_i=\mathrm{round}(\sqrt{(x_{u_i}-x_{v_i})^2+(y_{u_i}-y_{v_i})^2})$ とすると、
$l_i=\mathrm{rand}(d_i,3 d_i)$ により生成する。


ツール(入力ジェネレータ・ビジュアライザ)
--------
- <a href="https://img.atcoder.jp/ahc007/a855b6a456c9892b747e147001b0f89.zip">ローカル版</a>: 使用するには<a href="https://www.rust-lang.org/ja">Rust言語</a>のコンパイル環境をご用意下さい。
- <a href="https://img.atcoder.jp/ahc007/a855b6a456c9892b747e147001b0f89.html?lang=ja">Web版</a>: ローカル版より高性能でアニメーション表示が可能です。

<font color="red">コンテスト期間中に、seed=0 に対するビジュアライザの出力画像(pngもしくはgif)のみ twitter で共有が可能です。</font>必ず指定されたハッシュタグを用い、公開アカウントを使用して下さい。<a href="https://twitter.com/search?q=%23AHC007%20%23visualizer&src=typed_query&f=live">共有された画像の一覧</a>
