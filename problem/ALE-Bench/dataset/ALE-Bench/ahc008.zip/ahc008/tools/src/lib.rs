#![allow(non_snake_case, unused_macros)]

use itertools::*;
use proconio::{input, marker::Usize1};
use rand::prelude::*;
use std::io::prelude::*;
use std::process::ChildStdout;
use std::{collections::VecDeque, io::BufReader};
use svg::node::{
    element::{Definitions, Group, Image, Rectangle, Title, Use},
    Text,
};

pub trait SetMinMax {
    fn setmin(&mut self, v: Self) -> bool;
    fn setmax(&mut self, v: Self) -> bool;
}
impl<T> SetMinMax for T
where
    T: PartialOrd,
{
    fn setmin(&mut self, v: T) -> bool {
        *self > v && {
            *self = v;
            true
        }
    }
    fn setmax(&mut self, v: T) -> bool {
        *self < v && {
            *self = v;
            true
        }
    }
}

#[macro_export]
macro_rules! mat {
	($($e:expr),*) => { Vec::from(vec![$($e),*]) };
	($($e:expr,)*) => { Vec::from(vec![$($e),*]) };
	($e:expr; $d:expr) => { Vec::from(vec![$e; $d]) };
	($e:expr; $d:expr $(; $ds:expr)+) => { Vec::from(vec![mat![$e $(; $ds)*]; $d]) };
}

pub const D: usize = 30;
pub const T: usize = 300;
pub const DIR: [(usize, usize); 4] = [(!0, 0), (1, 0), (0, !0), (0, 1)];
pub const DIR_CHAR: [char; 5] = ['U', 'D', 'L', 'R', '.'];

pub type Output = Vec<(String, Vec<String>)>; // (human_move, comments)
pub type Output2 = Vec<(String, String, Vec<String>)>; // (human_move, pet_move, comments)

pub struct Input {
    pub ps: Vec<(usize, usize, usize)>,
    pub hs: Vec<(usize, usize)>,
    pub seed: u64,
}

impl std::fmt::Display for Input {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        writeln!(f, "{}", self.ps.len())?;
        for (x, y, t) in &self.ps {
            writeln!(f, "{} {} {}", x + 1, y + 1, t)?;
        }
        writeln!(f, "{}", self.hs.len())?;
        for (x, y) in &self.hs {
            writeln!(f, "{} {}", x + 1, y + 1)?;
        }
        Ok(())
    }
}

pub fn parse_input(f: &str) -> Input {
    let f = proconio::source::once::OnceSource::from(f);
    input! {
        from f,
        ps: [(Usize1, Usize1, usize)],
        hs: [(Usize1, Usize1)],
        seed: u64
    }
    Input { ps, hs, seed }
}

pub fn parse_output(_input: &Input, f: &str) -> Output {
    let mut out = vec![];
    let mut comments = vec![];
    for line in f.lines() {
        let line = line.trim();
        if line.starts_with('#') {
            comments.push(line[1..].trim().to_owned());
        } else if line.len() > 0 {
            out.push((line.to_owned(), comments));
            comments = vec![];
        }
    }
    out
}

pub fn parse_output2(_input: &Input, f: &str) -> Output2 {
    let mut out = vec![];
    let mut comments = vec![];
    let mut human = None;
    for line in f.lines() {
        let line = line.trim();
        if line.starts_with('#') {
            comments.push(line[1..].trim().to_owned());
        } else if line.len() > 0 {
            if let Some(h) = human {
                out.push((h, line.to_owned(), comments));
                comments = vec![];
                human = None;
            } else {
                human = Some(line.to_owned());
            }
        }
    }
    out
}

pub fn bfs(blocked: &Vec<Vec<bool>>, sx: usize, sy: usize) -> Vec<Vec<usize>> {
    let mut dist = mat![!0; D; D];
    let mut que = VecDeque::new();
    que.push_back((sx, sy));
    dist[sx][sy] = 0;
    while let Some((x, y)) = que.pop_front() {
        let t = dist[x][y];
        for d in 0..4 {
            let x2 = x + DIR[d].0;
            let y2 = y + DIR[d].1;
            if x2 < D && y2 < D && !blocked[x2][y2] && dist[x2][y2].setmin(t + 1) {
                que.push_back((x2, y2));
            }
        }
    }
    dist
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Pet {
    Cow,
    Pig,
    Rabbit,
    Dog(usize),
    Cat(usize, usize),
}

pub struct Sim {
    pub blocked: Vec<Vec<bool>>,
    pub rng: rand_chacha::ChaCha20Rng,
    pub ps: Vec<(usize, usize, Pet)>,
    pub hs: Vec<(usize, usize)>,
    pub turn: usize,
}

impl Sim {
    pub fn new(input: &Input) -> Self {
        Self {
            blocked: mat![false; D; D],
            rng: rand_chacha::ChaCha20Rng::seed_from_u64(input.seed),
            ps: input
                .ps
                .iter()
                .map(|&(x, y, t)| {
                    (
                        x,
                        y,
                        match t {
                            1 => Pet::Cow,
                            2 => Pet::Pig,
                            3 => Pet::Rabbit,
                            4 => Pet::Dog(!0),
                            5 => Pet::Cat(!0, !0),
                            _ => panic!("invalid input"),
                        },
                    )
                })
                .collect(),
            hs: input.hs.clone(),
            turn: 0,
        }
    }
    pub fn human_move(&mut self, out: &str) -> Result<(), String> {
        self.turn += 1;
        if out.len() != self.hs.len() {
            return Err(format!("illegal output length (turn {})", self.turn));
        }
        let mut new_hs = self.hs.clone();
        for (i, c) in out.chars().enumerate() {
            match c {
                '.' => (),
                c if c.is_ascii_lowercase() => {
                    if let Some(dir) = ['u', 'd', 'l', 'r'].iter().position(|&d| d == c) {
                        let x = self.hs[i].0 + DIR[dir].0;
                        let y = self.hs[i].1 + DIR[dir].1;
                        if x >= D || y >= D {
                            continue;
                        }
                        for j in 0..self.ps.len() {
                            if self.ps[j].0 == x && self.ps[j].1 == y {
                                return Err(format!(
                                    "trying to block a square containing a pet (turn {})",
                                    self.turn
                                ));
                            }
                        }
                        for j in 0..self.hs.len() {
                            if self.hs[j].0 == x && self.hs[j].1 == y {
                                return Err(format!(
                                    "trying to block a square containing a human (turn {})",
                                    self.turn
                                ));
                            }
                        }
                        for d in 0..4 {
                            let x2 = x + DIR[d].0;
                            let y2 = y + DIR[d].1;
                            if x2 < D
                                && y2 < D
                                && self.ps.iter().any(|&(x, y, _)| (x2, y2) == (x, y))
                            {
                                return Err(format!("trying to block a square whose adjacent square contains a pet (turn {})", self.turn));
                            }
                        }
                        self.blocked[x][y] = true;
                    } else {
                        return Err(format!("illegal output char {} (turn {})", c, self.turn));
                    }
                }
                c if c.is_ascii_uppercase() => {
                    if let Some(dir) = DIR_CHAR.iter().position(|&d| d == c) {
                        new_hs[i].0 += DIR[dir].0;
                        new_hs[i].1 += DIR[dir].1;
                        if new_hs[i].0 >= D || new_hs[i].1 >= D {
                            return Err(format!(
                                "trying to move to an impassible square (turn {})",
                                self.turn
                            ));
                        }
                    } else {
                        return Err(format!("illegal output char {} (turn {})", c, self.turn));
                    }
                }
                _ => return Err(format!("illegal output char {} (turn {})", c, self.turn)),
            }
        }
        self.hs = new_hs;
        for i in 0..self.hs.len() {
            if self.blocked[self.hs[i].0][self.hs[i].1] {
                return Err(format!(
                    "trying to move to an impassible square (turn {})",
                    self.turn
                ));
            }
        }
        Ok(())
    }
    pub fn standard_move(&mut self, x: &mut usize, y: &mut usize) -> usize {
        let mut cand = vec![];
        for d in 0..4 {
            let x2 = *x + DIR[d].0;
            let y2 = *y + DIR[d].1;
            if x2 < D && y2 < D && !self.blocked[x2][y2] {
                cand.push(d);
            }
        }
        let d = *cand.choose(&mut self.rng).unwrap();
        *x += DIR[d].0;
        *y += DIR[d].1;
        d
    }
    pub fn pet_move(&mut self) -> String {
        let mut ps = self.ps.clone();
        let ret = ps
            .iter_mut()
            .map(|(x, y, p)| match p {
                Pet::Cow => {
                    vec![DIR_CHAR[self.standard_move(x, y)]]
                }
                Pet::Pig => {
                    let mut ret = vec![];
                    for _ in 0..2 {
                        ret.push(DIR_CHAR[self.standard_move(x, y)]);
                    }
                    ret
                }
                Pet::Rabbit => {
                    let mut ret = vec![];
                    for _ in 0..3 {
                        ret.push(DIR_CHAR[self.standard_move(x, y)]);
                    }
                    ret
                }
                Pet::Dog(target) => loop {
                    if *target == !0 || self.hs[*target] == (*x, *y) {
                        let dist = bfs(&self.blocked, *x, *y);
                        let cand = (0..self.hs.len())
                            .filter(|&i| {
                                dist[self.hs[i].0][self.hs[i].1] != !0
                                    && dist[self.hs[i].0][self.hs[i].1] > 0
                            })
                            .collect::<Vec<_>>();
                        if let Some(i) = cand.choose(&mut self.rng) {
                            *target = *i;
                        } else {
                            *target = !0;
                            return vec![DIR_CHAR[self.standard_move(x, y)]];
                        }
                    }
                    let (tx, ty) = self.hs[*target];
                    let dist = bfs(&self.blocked, tx, ty);
                    if dist[*x][*y] == !0 {
                        *target = !0;
                        continue;
                    }
                    let mut cand = vec![];
                    for d in 0..4 {
                        let x2 = *x + DIR[d].0;
                        let y2 = *y + DIR[d].1;
                        if x2 < D && y2 < D && dist[*x][*y] > dist[x2][y2] {
                            cand.push(d);
                        }
                    }
                    let dir = *cand.choose(&mut self.rng).unwrap();
                    *x += DIR[dir].0;
                    *y += DIR[dir].1;
                    if self.hs[*target] == (*x, *y) {
                        *target = !0;
                    }
                    let ret = vec![DIR_CHAR[dir], DIR_CHAR[self.standard_move(x, y)]];
                    if *target != !0 && self.hs[*target] == (*x, *y) {
                        *target = !0;
                    }
                    return ret;
                },
                Pet::Cat(tx, ty) => loop {
                    if *tx != !0 && self.blocked[*tx][*ty] {
                        *tx = !0;
                        *ty = !0;
                    }
                    if *tx == !0 {
                        let dist = bfs(&self.blocked, *x, *y);
                        let mut cand = vec![];
                        for i in 0..D {
                            for j in 0..D {
                                if dist[i][j] != !0 && dist[i][j] > 0 {
                                    cand.push((i, j));
                                }
                            }
                        }
                        let (i, j) = *cand.choose(&mut self.rng).unwrap();
                        *tx = i;
                        *ty = j;
                    }
                    let dist = bfs(&self.blocked, *tx, *ty);
                    if dist[*x][*y] == !0 {
                        *tx = !0;
                        *ty = !0;
                        continue;
                    }
                    let mut cand = vec![];
                    for d in 0..4 {
                        let x2 = *x + DIR[d].0;
                        let y2 = *y + DIR[d].1;
                        if x2 < D && y2 < D && dist[*x][*y] > dist[x2][y2] {
                            cand.push(d);
                        }
                    }
                    let dir = *cand.choose(&mut self.rng).unwrap();
                    *x += DIR[dir].0;
                    *y += DIR[dir].1;
                    if (*tx, *ty) == (*x, *y) {
                        *tx = !0;
                        *ty = !0;
                    }
                    let ret = vec![DIR_CHAR[dir], DIR_CHAR[self.standard_move(x, y)]];
                    if (*tx, *ty) == (*x, *y) {
                        *tx = !0;
                        *ty = !0;
                    }
                    return ret;
                },
            })
            .map(|s| s.iter().collect::<String>())
            .join(" ");
        self.ps = ps;
        ret
    }
    pub fn apply_pet_move(&mut self, pet_move: &str) -> Result<(), String> {
        let pet_move = pet_move.split_whitespace().collect::<Vec<_>>();
        if pet_move.len() != self.ps.len() {
            return Err(format!("illegal pet_move length (turn {})", self.turn));
        }
        for (i, s) in pet_move.into_iter().enumerate() {
            for c in s.chars() {
                match c {
                    '.' => (),
                    c => {
                        if let Some(dir) = DIR_CHAR.iter().position(|&d| d == c) {
                            self.ps[i].0 += DIR[dir].0;
                            self.ps[i].1 += DIR[dir].1;
                            if self.ps[i].0 >= D
                                || self.ps[i].1 >= D
                                || self.blocked[self.ps[i].0][self.ps[i].1]
                            {
                                return Err(format!(
                                    "a pet is trying to move to an impassible square (turn {})",
                                    self.turn
                                ));
                            }
                        } else {
                            return Err(format!(
                                "illegal pet_move char {} (turn {})",
                                c, self.turn
                            ));
                        }
                    }
                }
            }
        }
        Ok(())
    }
    pub fn compute_score(&self) -> i64 {
        let mut score = 0.0;
        for &(x, y) in &self.hs {
            let dist = bfs(&self.blocked, x, y);
            let mut r = 0;
            for i in 0..D {
                for j in 0..D {
                    if dist[i][j] != !0 {
                        r += 1;
                    }
                }
            }
            let mut n = 0;
            for &(px, py, _) in &self.ps {
                if dist[px][py] != !0 {
                    n += 1;
                }
            }
            score += r as f64 / (30.0 * 30.0) * 2.0f64.powi(-n);
        }
        (1e8 * score / self.hs.len() as f64).round() as i64
    }
}

pub fn gen(seed: u64) -> Input {
    let mut rng = rand_chacha::ChaCha20Rng::seed_from_u64(seed ^ 386617);
    let mut free = vec![];
    for i in 0..D {
        for j in 0..D {
            free.push((i, j));
        }
    }
    let N = rng.gen_range(10i32, 21) as usize;
    let mut ps = vec![];
    for _ in 0..N {
        let k = rng.gen_range(0, free.len() as i32) as usize;
        ps.push((free[k].0, free[k].1, rng.gen_range(1i32, 6) as usize));
        free.swap_remove(k);
    }
    let M = rng.gen_range(5i32, 11) as usize;
    let mut hs = vec![];
    for _ in 0..M {
        let k = rng.gen_range(0, free.len() as i32) as usize;
        hs.push(free[k]);
        free.swap_remove(k);
    }
    let seed = rng.gen();
    Input { ps, hs, seed }
}

fn rect(x: i32, y: i32, w: i32, h: i32, fill: &str) -> Rectangle {
    Rectangle::new()
        .set("x", x)
        .set("y", y)
        .set("width", w)
        .set("height", h)
        .set("fill", fill)
}

pub fn vis_default(input: &Input, out: &Output) -> (String, String) {
    let mut sim = Sim::new(input);
    let mut err = String::new();
    for i in 0..T {
        if let Err(e) = sim.human_move(&out[i].0) {
            err = e;
            break;
        }
        sim.pet_move();
    }
    (vis(input, &sim), err)
}

const IMAGES: [&'static str; 7] = [
	// https://dotown.maeda-design-room.net/2352/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYCAYAAAC+ZpjcAAALSklEQVR4nO3YsYpdRRzA4R3diGBhkLSm2G2MkDIWSRXEShuLWAW3sPdRLHyDiJUpbLSUNNEHMGBskiK2kSyCzYoc0cZOEH73nrM73/cCM/M/957zYw4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYMfGbANelmUDu2BXxhgeMJxTy7JM9U0aH365yrrL13dXWXeMuZLjpQ3sAQDgQhFYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEDs00Ivts5Mby0znfXbv2gZ2sT/3v3ttlqP+4867v29gF+zKGGOq99XfR15n2bvrLDsZN1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAALEx20Cf3bu2bGAbe/Pmxz9N9Yx/+eLtqZ4vcH5dPXm8yvt5WdZ5TY4xV3K4wQIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiI3ZBnr94YtlA9vYp6me8bdPbk71fP/45nQDu9ifSx9cnuWoU3r/+Afvqwvs6snjqZ6vGywAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgNiYbaDXH75YNrCNvXnw1p+TnHROX125MtW5P3r+fAO7gMbtn19eZ5JjnU//o1uXp2oON1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAADGBBQAQE1gAALHD2Qb64ztjbGAbe/Prb5Mc9F/LVjbCxfHk6dOpnubx0dFaS0/1fr7xxqvrLLzSZ/DRKquuxw0WAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEBMYAEAxAQWAEDs0EAB/tvx0ZEJAf+LGywAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgNiYbaDL2ekGdsGujFc+XwwXzqfl7NO5vkmXXt/AJvZnjLkerxssAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAIDYmG2gy9npBnaxP98/uL/MctZJrfIfvnX7zuxz34u1/r9jTPdpWMsqg7753ierHHe235UbLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACA2KGBAmzTGGOVfS3Lssq6a50XdsENFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJwnBwcHfwGrplZmpCMsxQAAAABJRU5ErkJggg==",
	// https://dotown.maeda-design-room.net/318/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAGkCAYAAADt3lsjAAAG7ElEQVR4nO3YS23DQBRAUacKkCxCIFIBlUGxlEHAdFnJBLwwgHJwSdz6E59DYN48L3w1AwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8s8vZFvz18b7sYAwAOJXP58+pmuNtBzMAALwUgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAAAxgQUAEBNYAACx69kWOk7zDqZY1WWLQx/323Y3BjiAcZoX3+l1ecECAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIhdz7bQx/22gylWtZzorgCHcbb/0fP7dwdTrMcLFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBATGABAMQEFgBA7Hq2hY7TvIMpVnXZ4tDH/bbdjQEOYJzmxXd6XV6wAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAABiAgsAICawAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4EiGYfgDq24XrQ1PyUwAAAAASUVORK5CYII=",
	// https://dotown.maeda-design-room.net/442/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAApQAAAIcCAYAAABILD6JAAAJ90lEQVR4nO3YIW5UURSA4Xmkqe4S2AQGT4Ijwc+Y6kkwbAKDqK4ZPAmuSX0FoqYSBGEHaMRD0A2Qn768mft9Kzj33JmXP3cDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/2gabWEfPn5dwRTLefv8yzzKWR+N9pse6n4//3gz3DcLTsX7dy+GustpGutz9WwFMwAAcMQEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgORttfQ/3V/MKxljMw/0gB310uB7rfneX+xVMsaSx7nez2UwrmAH+k4NFnjAvlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJCcDbi+aQUzLObu9mYe5KhDuru9GerYL1+9Hur/C3AsvFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAcmZ9p+37z2+jr+CkjXa/u8v9vIIxFnO4vhrkpH/tLvdrGIMnstvtRlvttIIZFuOFEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAAJIz6zttu8v9NNJ5D1ef5hWMsZjdfjvISQFYMy+UAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkEyjrW+73a5gCp7QbLmn63B9NfoKgCMxnV8M1VheKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACCZRlvfPM8rmGJBv38Nc9RHg13weP9h4GgN9X2ezi+G+j57oQQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAIBEUAIAkAhKAAASQQkAQCIoAQBIBCUAAImgBAAgEZQAACSCEgCARFACAJAISgAAEkEJAEAiKAEASAQlAACJoAQAIBGUAAAkghIAgERQAgCQCEoAABJBCQBAIigBAEgEJQAAiaAEACARlAAAJIISAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYzmaz+QMK3Dg4nFBadAAAAABJRU5ErkJggg==",
	// https://dotown.maeda-design-room.net/582/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAtAAAAJYCAYAAABLtNEpAAALtElEQVR4nO3YsXHTYBiA4YjzEB6AMUiRnFkitSkyBNxxDEGBW1gCHymSMeiTLURBRwPvHbEV/c+zgD59kuz3/gsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIY3jbaAx5sP8wLG4Jlsry6tdsWe7u5HX8Gqbb9+HOs/6XA8z3X3u/Ncl1WbprE+31cLmAEAAF4MAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAYGNZ67a9uhx9BazIaO/z0939AqYA4E9OoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAim0ZY1f/k+L2CMk3n9/maQO/3t56dvSxjjZDxfVmW/G+4/CdZimsb6fJ1AAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQbywIAnt3heJ4d73eeLf+dE2gAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAYBptWY83H+YFjAHwV9urS0tiTc7THPvdeVZ4OA7VG9O7t0M1pRNoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAgo1lrdubH5+Hut+H69sFTHE6ni/wgsxnGfVw9I7w3zmBBgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAINhY1ro9XN+OvoJV83wBFmvyaNbLCTQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAADBZsBlTQuY4WS2V5fzILcKAMux3431MN4tYIYTcgINAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAIKABACAQ0AAAEAhoAAAIBDQAAAQCGgAAAgENAACBgAYAgEBAAwBAMI22rHmeFzDFCR2Og93wmd7p/e4slx2O93ndRvuODscFDHFSY32/+91Q3+80jfVz5QQaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgCAQEADAEAgoAEAIBDQAAAQCGgAAAgENAAABAIaAAACAQ0AAIGABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4VxcXF78AZwQ9NgHGBNUAAAAASUVORK5CYII=",
	// https://dotown.maeda-design-room.net/479/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAhwAAAKUCAYAAABPHeHJAAAK1klEQVR4nO3YsW4TURBA0V3k0IbSFXRAA6Li/+tUUdLlB0jr2sUiARX9XW0853zBvHmy9+otAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcDTrtBvZtu0AU5C5XqZd8LTfsPu9ZXf3o467rrOu990BZgAAbpzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMidrPjGXS/b9BXcOPcLvAleOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyJ2mrfj166ftAGPs5vz8NOSkf71++36EMXYz7X6Bt8sLBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAudPAFa8HmGFP25yjLsv5+ekAUwDwPy8cAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDk1mkr/vXl4wGmoHJ+ftosF96sUd+k9f2HA0yxHy8cAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDk1mkr3rbtAFPs6HoZc9R/hl0w3JC7+1HfpHWd9Qn2wgEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQE5wAAA5wQEA5AQHAJATHABATnAAADnBAQDkBAcAkBMcAEBOcAAAOcEBAOQEBwCQExwAQO5kxbft4fFlm3Tenz8+H2CK/Tw8vkw56h/T7nec62XU/9WyLOsBZtiNFw4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAHKCAwDICQ4AICc4AICc4AAAcoIDAMgJDgAgJzgAgJzgAAByggMAyAkOACAnOACAnOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYJZlWX4DxiEsu4Gk4vQAAAAASUVORK5CYII=",
	// https://dotown.maeda-design-room.net/532/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAwwAAALQCAYAAAA99PebAAAO20lEQVR4nO3ZsW0cVxRAUa4xLUiw4FCqwqEIuApFDgwBKmL+tOHAhRigAgWugqlBgE2sYSi+gUByZ7j/nAbmz/vYwV68GwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACuzmm2Kz2fzwc4BS9lbNtUFzzWdarf8Gz3u9c3eqzrHo8FeDVOp7n+Qv90gDMAAAAHJRgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC0GA28XmPbzq4PAHhJNgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQDrNNpr3P785H+AYF/Pp85dJ3vS7r3d3RzjGxXy8vZ3kTb+b7X73+kZ/+/Ztj8fe/PP3n7s899ff/tjlucDrdTrN9RfahgEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIvRAAA8rw/v3u4y0fuHRzfJs7NhAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAACSYAAAAJJgAAAAkmAAAADSMuFoTgc4wyWd53nVm5uPt7cHOAUvZbb7/Xp3d4BT8FL+/evDLrP95fd7d3oB9w+PV/+OzMOGAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIggEAAEiCAQAASIIBAABIp9lG8/7nNwc4xeV8+vzlPMu7AgBcwjbGVP+hbRgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgLTMNpr7h8cDnOJyxrbN8qoAALwAGwYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC1GAwDAU4x1Pc00wG2MA5zicmwYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC0zDaasW0HOMVFnSZ61/+dD3AGAICrYcMAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAACTBAAAAJMEAAAAkwQAAAKTFaAAAeIqxbeZ3xWwYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC0zDaasa4HOAUvZWyb2QIAPCMbBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgLUYDAMBTjHWdan7bGAc4xeXYMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAASTAAAABJMAAAAEkwAAAAaTEaAACeYmyb+V0xGwYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC1GA6/aabLrOx/gDJc02/1OZazr7CO4amPbZvte7WKv39E2xu7vfkk2DAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAEgwAAEASDAAAQBIMAABAWowGALhWY9vcLTyRDQMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkAQDAACQBAMAAJAEAwAAkBajAX7UWNddZja2zV1dwF73++Hd212eu5e95gzwo2wYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIC0GA28XmNd3R5X4/7h0WXy7Pb6To5tc5lcDRsGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAACAJBgAAIAkGAAAgCQYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAWdzc3PwHoFNab0L7+VsAAAAASUVORK5CYII=",
	// https://dotown.maeda-design-room.net/587/
	"data:image/png;charset=utf-8;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAKUCAYAAADYTEYTAAALsklEQVR4nO3YsY0TQRiAUS/yxRRwSAS4gEuPAkiogkNQBSFVgDBVkFAApBRwBEi4AGKCRYKMAAnpO+/a814DO/OPNf40GwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC4Y9NoA57neQWrAOBvh/1utAt6kf/gy5vbJT67maaxkuPeCtYAAHBWBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEBBYAQExgAQDEtgYKp+vDi4eLrP3p229+NQD/4AULACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACAmsAAAYgILACC2HW2gh/1uXsEyjmla4qOXN7eLbHa08726vljkfIHTddjvnN4ReMECAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIhtDfTszUts8LDfjTVlgP+3yP28oGmkzXrBAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCIbUcb6Kv3P1awiuN5/ez+KFv9zfnCSZsGO755BWvgjnjBAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCICSwAgJjAAgCITaMN9Pu7R/MKlnE0Xz7/HGSnf1xdX6xhGQD85cHzr0M1hxcsAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAICYwAIAiAksAIDY1kDP29X1xegjAICj84IFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABATWAAAMYEFABDbGujZmwbb77yCNRzTaOcL52S0+2ooXrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGICCwAgJrAAAGJbA+UuXN7cLjLXw37nPI9gqfPlvH36+GaR/T1+8nKR77qvzpsXLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLACAmMACAIgJLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADglm83mF1wiNBWQbA1GAAAAAElFTkSuQmCC",
];

pub fn vis(input: &Input, sim: &Sim) -> String {
    const W: i32 = 30;
    let mut doc = svg::Document::new()
        .set("id", "vis")
        .set("viewBox", (0, 0, D as i32 * W, D as i32 * W))
        .set("width", D as i32 * W)
        .set("height", D as i32 * W);

    doc = doc.add(
        Definitions::new()
            .add(
                Image::new()
                    .set("id", "human")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[0]),
            )
            .add(
                Image::new()
                    .set("id", "block")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[1]),
            )
            .add(
                Image::new()
                    .set("id", "cow")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[2]),
            )
            .add(
                Image::new()
                    .set("id", "pig")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[3]),
            )
            .add(
                Image::new()
                    .set("id", "rabbit")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[4]),
            )
            .add(
                Image::new()
                    .set("id", "dog")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[5]),
            )
            .add(
                Image::new()
                    .set("id", "cat")
                    .set("width", W)
                    .set("height", W)
                    .set("image-rendering", "pixelated")
                    .set("href", IMAGES[6]),
            ),
    );

    doc = doc.add(rect(0, 0, D as i32 * W, D as i32 * W, "white"));
    for i in 0..D {
        for j in 0..D {
            doc = doc.add(
                Group::new()
                    .add(rect(
                        j as i32 * W + 1,
                        i as i32 * W + 1,
                        W - 2,
                        W - 2,
                        "silver",
                    ))
                    .add(Title::new().add(Text::new(format!("({}, {})", i + 1, j + 1)))),
            );
            if sim.blocked[i][j] {
                doc = doc.add(
                    Group::new()
                        .add(
                            Use::new()
                                .set("x", j as i32 * W)
                                .set("y", i as i32 * W)
                                .set("href", "#block"),
                        )
                        .add(Title::new().add(Text::new(format!("({}, {})", i + 1, j + 1)))),
                );
            }
        }
    }
    for i in 0..sim.hs.len() {
        doc = doc.add(
            Group::new()
                .add(
                    Use::new()
                        .set("x", sim.hs[i].1 as i32 * W)
                        .set("y", sim.hs[i].0 as i32 * W)
                        .set("href", "#human"),
                )
                .add(Title::new().add(Text::new(format!(
                    "({}, {})\nhuman {}",
                    sim.hs[i].0 + 1,
                    sim.hs[i].1 + 1,
                    i + 1
                )))),
        )
    }
    for i in 0..sim.ps.len() {
        let name = ["#cow", "#pig", "#rabbit", "#dog", "#cat"][input.ps[i].2 - 1];
        let title = match sim.ps[i].2 {
            Pet::Cow => format!("pet {} (cow)", i + 1),
            Pet::Pig => format!("pet {} (pig)", i + 1),
            Pet::Rabbit => format!("pet {} (rabbit)", i + 1),
            Pet::Dog(t) => format!(
                "pet {} (dog)\ntarget: {}",
                i + 1,
                if t == !0 {
                    "none".to_owned()
                } else {
                    (t + 1).to_string()
                }
            ),
            Pet::Cat(tx, ty) => format!(
                "pet {} (cat)\ntarget: {}",
                i + 1,
                if tx == !0 {
                    "none".to_owned()
                } else {
                    format!("({}, {})", tx + 1, ty + 1)
                }
            ),
        };
        doc = doc.add(
            Group::new()
                .add(
                    Use::new()
                        .set("x", sim.ps[i].1 as i32 * W)
                        .set("y", sim.ps[i].0 as i32 * W)
                        .set("href", name),
                )
                .add(Title::new().add(Text::new(&format!(
                    "({}, {})\n{}",
                    sim.ps[i].0 + 1,
                    sim.ps[i].1 + 1,
                    title
                )))),
        );
    }
    doc.to_string()
}

fn read_line(stdout: &mut BufReader<ChildStdout>, local: bool) -> Result<String, String> {
    loop {
        let mut out = String::new();
        match stdout.read_line(&mut out) {
            Ok(0) | Err(_) => {
                return Err(format!("Your program has terminated unexpectedly"));
            }
            _ => (),
        }
        if local {
            print!("{}", out);
        }
        let v = out.trim();
        if v.len() == 0 || v.starts_with("#") {
            continue;
        }
        return Ok(v.to_owned());
    }
}

pub fn exec(p: &mut std::process::Child, local: bool) -> Result<i64, String> {
    let mut input = String::new();
    std::io::stdin().read_to_string(&mut input).unwrap();
    let input = parse_input(&input);
    let mut stdin = std::io::BufWriter::new(p.stdin.take().unwrap());
    let mut stdout = std::io::BufReader::new(p.stdout.take().unwrap());
    write!(stdin, "{}", input).unwrap();
    stdin.flush().unwrap();
    let mut sim = Sim::new(&input);
    for _ in 1..=T {
        let out = read_line(&mut stdout, local)?;
        sim.human_move(&out)?;
        let pet_move = sim.pet_move();
        let _ = writeln!(stdin, "{}", pet_move);
        let _ = stdin.flush();
    }
    p.wait().unwrap();
    let score = sim.compute_score();
    Ok(score)
}
